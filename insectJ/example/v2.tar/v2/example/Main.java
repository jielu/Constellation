package example;

public class Main {

	public static void main(String[] args) {
		Example ex = new Example();
		ex.go(args);
	}
}
